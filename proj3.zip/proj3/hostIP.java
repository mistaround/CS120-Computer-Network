public class hostIP {

    public static final String NODE1A = "192.168.1.2";
    public static final String NODE2A = "192.168.1.1";

    public static final String NODEss = "10.20.208.53";
    public static final String NODEmac = "10.20.225.34";
    public static final String NODEsz = "10.20.221.121";

    public static final String[][] NAT =
            {
                    {,},
                    {,},
                    {,}
            };

}
