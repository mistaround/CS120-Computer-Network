import java.awt.*;
import java.io.*;
import java.util.Arrays;
import java.util.Scanner;
import java.net.*;
import java.util.Random;

public class Proj3 {
    private static final int BUFFER_MAX = 1024;
    public static void main(String[] args)
    {
        System.out.println("============================");
        System.out.println("Which do you want to choose?");
        System.out.println("============================");
        System.out.println(" 1. Part1 Socket Server");
        System.out.println(" 2. Part1 Socket Client");
        System.out.println(" 3. Part2-1 Cable Sender");
        System.out.println(" 4. Part2 NAT C->W");
        System.out.println(" 5. Part2-1 Wifi Receiver");
        System.out.println(" 6. Part2-1 Wifi Sender");
        System.out.println(" 7. Part2 NAT W->C");
        System.out.println(" 8. Part2-1 Cable Receiver");
        System.out.println("============================");

        Scanner input = new Scanner(System.in);
        int sel = input.nextInt();

        String fileName = "INPUT.bin";

        switch(sel)
        {
            case 1: {
                try {
                    int port = 5555;
                    DatagramSocket datagramSocket = new DatagramSocket(port);
                    System.out.println("UDP Sever Set Up On Port:" + port);
                    System.out.println("Receiving Message");
                    while(true)
                    {
                        DatagramPacket datagramPacket = new DatagramPacket(new byte[BUFFER_MAX], BUFFER_MAX);
                        datagramSocket.receive(datagramPacket);
                        InetAddress address = datagramPacket.getAddress();
                        System.out.println("Message Received: " + new String(datagramPacket.getData())  + " From IP: " + address.getHostAddress() + " Port:" + datagramPacket.getPort());
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
                break;
            }
            case 2: {
                try {
                    String host = hostIP.NODEss;
                    InetAddress address = Inet4Address.getByName(host);
                    int port = 5555;
                    Random rand = new Random();
                    DatagramSocket datagramSocket = new DatagramSocket();
                    int i = 1;
                    while (i < 11)
                    {
                        System.out.println("-------------" + i + " second --------------");
                        byte[] message = new byte[20];
                        rand.nextBytes(message);
                        DatagramPacket datagramPacket = new DatagramPacket(message, message.length, address, port);
                        datagramPacket.setPort(port);
                        datagramSocket.send(datagramPacket);
                        System.out.println("Sent message: " + new String(message));
                        Thread.sleep(1000);
                        i += 1;
                    }

                } catch (Exception e) {
                    e.printStackTrace();
                }
                break;
            }
            case 3: {
                PhyLayer phyLayer = new PhyLayer();
                try {
                    System.out.println("Working As Cable Sender");
                    String src = hostIP.NODE1A;
                    String dest = hostIP.NODEmac;
                    MACLayer macLayer = new MACLayer(dest, src, phyLayer);
                    phyLayer.macLayer = macLayer;
                    System.out.println("From: " + src + " To: " + dest);

                    phyLayer.sender.readFile("INPUT.txt");
                    int len = phyLayer.sender.fileContent.length;
                    int pkgNum = 10;
                    int size = len / pkgNum;
                    int offset = len % pkgNum;

                    ByteArrayOutputStream bytes = new ByteArrayOutputStream();
                    for(int i = 0; i < pkgNum; i++)
                    {
                        bytes.write(phyLayer.sender.fileContent, i*size, size);
                        macLayer.send(PhyLayer.SEND, i, bytes.toByteArray(), false);
                        bytes.reset();
                    }
                    if (offset != 0)
                    {
                        bytes.write(phyLayer.sender.fileContent, pkgNum*size, offset);
                        macLayer.send(PhyLayer.SEND, pkgNum, bytes.toByteArray(), false);
                        bytes.reset();
                    }

                } catch (Exception e) {
                    e.printStackTrace();
                }
                break;
            }
            case 4: {
                PhyLayer phyLayer = new PhyLayer();
                phyLayer.receiver.started = false;
                try {
                    System.out.println("Working As NAT Cable to Wireless");
                    System.out.println("Receiving ...");

                    Thread.sleep(5000);
                    byte[][] buffer = phyLayer.receiver.currContent.clone();
                    phyLayer.runReceiver(false);

                    String src = MACLayer.longToIP(phyLayer.receiver.Src);
                    String dest = MACLayer.longToIP(phyLayer.receiver.Dest);
                    InetAddress address = Inet4Address.getByName(dest);
                    int port = 5555;
                    DatagramSocket datagramSocket = new DatagramSocket(port);

                    System.out.println();
                    System.out.println("------Sending UDP Packages------");
                    System.out.println("From: " + src + " To: " + address);

                    for (byte[] tmp : buffer) {
                        byte[] message = MACLayer.PackUpNAT(tmp, dest, src);
                        DatagramPacket datagramPacket = new DatagramPacket(message, message.length, address, port);
                        datagramPacket.setPort(port);
                        datagramSocket.send(datagramPacket);
                    }

                } catch (Exception e) {
                    e.printStackTrace();
                }
                break;
            }
            case 5: {
                try {
                    System.out.println("Working As Wifi Receiver");
                    int port = 5555;
                    DatagramSocket datagramSocket = new DatagramSocket(5555);
                    System.out.println("UDP Sever Set Up On Port " + port);
                    System.out.println("Receiving Message...");
                    int num = 0;
                    while(true)
                    {
                        DatagramPacket datagramPacket = new DatagramPacket(new byte[BUFFER_MAX], BUFFER_MAX);
                        datagramSocket.receive(datagramPacket);
                        String[] header = MACLayer.UnpackNAT(datagramPacket.getData());
                        byte[] data = Arrays.copyOfRange(datagramPacket.getData(),16,datagramPacket.getData().length);;
                        byte[] resultBuf = new byte[data.length / 8];
                        for(int j=0; j<data.length; j+=8)
                            resultBuf[j/8] = (byte) binUtils.getNum(j, 8, data);
                        assert header != null;
                        System.out.println();
                        System.out.println("Message# " + num + " Received From IP: " + datagramPacket.getAddress() + " Port:" + port);
                        System.out.println("Content: ");
                        System.out.println(new String(resultBuf));
                        num ++;
                    }

                } catch (Exception e) {
                    e.printStackTrace();
                }
                break;
            }
            case 6: {
                try {
                    System.out.println("Working As Wifi Sender");
                    System.out.println("------Sending UDP Packages------");
                    String dest = hostIP.NODE1A;
                    String src = hostIP.NODEmac;
                    // TODO NAT Table
                    String NAT = hostIP.NODEss;
                    System.out.println("From: " + src + " To: " + dest + " By GATEWAY: " + NAT);
                    InetAddress address = Inet4Address.getByName(NAT);
                    int port = 5555;
                    DatagramSocket datagramSocket = new DatagramSocket(port);

                    FileInputStream is = new FileInputStream("INPUT.txt");
                    int avail = is.available();
                    byte[] content = new byte[avail];
                    is.read(content);
                    System.out.println("Sending file length: " + content.length);

                    byte[][] buf = new byte[30][];
                    byte[] newfile = new byte[1200];
                    int begin = 0;
                    int idx = 0;
                    int num = 0;
                    while (num < buf.length)
                    {
                        begin = idx;
                        while (idx < content.length && content[idx] != '\n')
                        {
                            idx ++;
                        }
                        buf[num] = Arrays.copyOfRange(content, begin ,idx - 1);
                        num ++;
                        idx ++;
                    }
                    for (int i = 0; i < num; i++)
                    {
                        int len = buf[i].length;
                        for (int j = 0; j < 39; j++)
                        {
                            if (j < len)
                            {
                                newfile[i * 40 + j] = buf[i][j];
                            }
                            else
                            {
                                newfile[i * 40 + j] = ' ';
                            }
                        }
                        newfile[i * 40 + 39] = '\n';
                    }

                    content = newfile.clone();

                    int len = content.length;
                    int pkgNum = 30;
                    int size = len / pkgNum;
                    int offset = len % pkgNum;

                    for(int i = 0; i < pkgNum; i++)
                    {
                        byte[] tmp = Arrays.copyOfRange(content,i*size,(i+1)*size);
                        byte[] message = MACLayer.PackUpNAT(tmp,dest,src);
                        assert message != null;
                        DatagramPacket datagramPacket = new DatagramPacket(message, message.length, address, port);
                        datagramPacket.setPort(port);
                        datagramSocket.send(datagramPacket);
                        System.out.println();
                        System.out.println("Sent message #" + i +" : " + new String(tmp));
                    }
                    if (offset != 0)
                    {
                        byte[] tmp = Arrays.copyOfRange(content,pkgNum * size,pkgNum * size + offset);
                        byte[] message = MACLayer.PackUpNAT(tmp,dest,src);
                        assert message != null;
                        DatagramPacket datagramPacket = new DatagramPacket(message, message.length, address, port);
                        datagramPacket.setPort(port);
                        datagramSocket.send(datagramPacket);
                        System.out.println();
                        System.out.println("Sent message #" + pkgNum + " : " + new String(tmp));
                    }

                } catch (Exception e) {
                    e.printStackTrace();
                }
                break;
            }
            case 7: {
                PhyLayer phyLayer = new PhyLayer();
                try {
                    System.out.println("Working As NAT Wireless to Cable");
                    System.out.println("Receiving ...");

                    byte[] buffer = new byte[50000];
                    int port = 5555;
                    DatagramSocket datagramSocket = new DatagramSocket(port);
                    datagramSocket.setSoTimeout(2500);
                    System.out.println("UDP Sever Set Up On Port:" + port);
                    System.out.println("Receiving Message with 5 seconds Time Out");

                    int num = 0;
                    int last = 0;
                    String src = "OVO", dest = "OVO";

                    long startTime = System.currentTimeMillis();
                    try
                    {
                        while((System.currentTimeMillis() - startTime) < 5000)
                        {
                            DatagramPacket datagramPacket = new DatagramPacket(new byte[BUFFER_MAX], BUFFER_MAX);
                            datagramSocket.receive(datagramPacket);

                            byte[] data = datagramPacket.getData();
                            int dataLen = datagramPacket.getLength();
                            String[] IPs = MACLayer.UnpackNAT(data);
                            byte[] message = Arrays.copyOfRange(data,16, dataLen);
                            int len = message.length;
                            assert IPs != null;
                            dest = IPs[0]; src = IPs[1];
                            for (int i = 0; i < len; i++)
                            {
                                buffer[last + i] = message[i];
                            }
                            last += len;

                            System.out.println("Package #" + num + " From: " + src + " To: " + dest);
                            System.out.println(new String(message));
                            System.out.println();
                            num ++;
                        }
                    }
                    catch (SocketTimeoutException e)
                    {
                        System.out.println("Total Length of Received Bytes: " + last);
                        byte[] content = Arrays.copyOfRange(buffer,0, last);


                        System.out.println();
                        System.out.println("------Transmitting To: " + dest + " On Cable------");

                        MACLayer macLayer = new MACLayer(dest, src, phyLayer);
                        phyLayer.sender.fileContent = content.clone();
                        int len = phyLayer.sender.fileContent.length;
                        int pkgNum = 10;
                        int size = len / pkgNum;
                        int offset = len % pkgNum;
                        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
                        for(int i = 0; i < pkgNum; i++)
                        {
                            bytes.write(phyLayer.sender.fileContent, i*size, size);
                            macLayer.send(PhyLayer.SEND, i, bytes.toByteArray(), false);
                            bytes.reset();
                        }
                        if (offset != 0)
                        {
                            bytes.write(phyLayer.sender.fileContent, pkgNum*size, offset);
                            macLayer.send(PhyLayer.SEND, pkgNum, bytes.toByteArray(), false);
                            bytes.reset();
                        }
                    }

                } catch (Exception e) {
                    e.printStackTrace();
                }
                break;
            }
            case 8: {
                PhyLayer phyLayer = new PhyLayer();
                phyLayer.receiver.started = false;
                try {
                    System.out.println("Working As Cable Receiver");
                    System.out.println("Receiving ...");
                    Thread.sleep(10000);
                    phyLayer.runReceiver(false);

                    byte[][] buffer = phyLayer.receiver.currContent.clone();
                    String src = MACLayer.longToIP(phyLayer.receiver.Src);
                    int port = 5555;

                    int i = 0;
                    while(i < buffer.length)
                    {
                        byte[] data = buffer[i];;
                        byte[] resultBuf = new byte[data.length / 8];
                        for(int j=0; j<data.length; j+=8)
                            resultBuf[j/8] = (byte) binUtils.getNum(j, 8, data);
                        System.out.println();
                        System.out.println("Message #" + i + " Received From IP: " + src + " Port:" + port);
                        System.out.println("Content: ");
                        System.out.println();
                        System.out.println(new String(resultBuf));
                        i++;
                    }

                    phyLayer.runReceiver(false);
                } catch (Exception e) {
                    e.printStackTrace();
                }
                break;
            }
        }
    }
}
