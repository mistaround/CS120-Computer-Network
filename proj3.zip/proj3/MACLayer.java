import java.io.ByteArrayOutputStream;
import java.util.Arrays;

/* Mac Layer
*  Only usage is to pack up PhyLayer package with dummy dest&src
*  And NAT translation */
public class MACLayer {
    public PhyLayer phyLayer;
    public static final int MAC_HEADER_LEN = 16 * 8;
    public long Dest;
    public long Src;

    public MACLayer(String Dest, String Src, PhyLayer phyLayer)
    {
        try
        {
            this.Dest = ipToLong(Dest);
            this.Src = ipToLong(Src);
            this.phyLayer = phyLayer;
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
    }

    /* Reference CSDN */
    public static long ipToLong(String strIp) {
        String[]ip = strIp.split("\\.");
        return (Long.parseLong(ip[0]) << 24) + (Long.parseLong(ip[1]) << 16) + (Long.parseLong(ip[2]) << 8) + Long.parseLong(ip[3]);
    }

    /* Reference CSDN */
    public static String longToIP(long longIp) {
        return "" + (longIp >>> 24) +
                "." +
                ((longIp & 0x00FFFFFF) >>> 16) +
                "." +
                ((longIp & 0x0000FFFF) >>> 8) +
                "." +
                (longIp & 0x000000FF);
    }

    /* Reference CSDN */
    public static byte[] longToByte(long res) {
        byte[] buffer = new byte[8];
        for (int i = 0; i < 8; i++) {
            int offset = 64 - (i + 1) * 8;
            buffer[i] = (byte) ((res >> offset) & 0xff);
        }
        return buffer;
    }

    /* Reference CSDN */
    public static long byteToLong(byte[] b){
        long values = 0;
        for (int i = 0; i < 8; i++) {
            values <<= 8; values|= (b[i] & 0xff);
        }
        return values;
    }

    public byte[] PackUpPhy(byte[] content)
    {
        try
        {
            int len = content.length;
            byte[] MacPack = new byte[len + 16];
            byte[] dest = longToByte(this.Dest);
            byte[] src = longToByte(this.Src);
            for (int i = 0; i < MacPack.length; i++)
            {
                if (i < 8)
                {
                    MacPack[i] = dest[i];
                }
                else if (i < 16)
                {
                    MacPack[i] = src[i-8];
                }
                else
                {
                    MacPack[i] = content[i-16];
                }
            }
            return MacPack;
        }
        catch (Exception e)
        {
            e.printStackTrace();
            return null;
        }
    }

    public void UnPackPhy(byte[] pack, int offset)
    {
        try
        {
            byte[] dest = new byte[8];
            byte[] src = new byte[8];
            for (int i = 0; i < 8; i++)
            {
                dest[i] = pack[i + offset];
            }
            for (int i = 0; i < 8; i++)
            {
                src[i] = pack[i + offset + 8];
            }

            this.Dest = byteToLong(dest);
            this.Src = byteToLong(src);
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
    }

    public static byte[] PackUpNAT(byte[] message, String dest, String src)
    {
        try
        {
            byte[] pack = new byte[message.length + 16];
            byte[] srcBytes = longToByte(ipToLong(src));
            byte[] destBytes = longToByte(ipToLong(dest));
            for (int i = 0; i < 8; i++)
            {
                pack[i] = destBytes[i];
            }
            for (int i = 0; i < 8; i++)
            {
                pack[i+8] = srcBytes[i];
            }
            for (int i = 0; i < message.length; i ++)
            {
                pack[i+16] = message[i];
            }
            return pack;
        }
        catch (Exception e)
        {
            e.printStackTrace();
            return null;
        }
    }

    public static String[] UnpackNAT(byte[] pack)
    {
        try
        {
            byte[] dest = Arrays.copyOfRange(pack,0,8);
            byte[] src = Arrays.copyOfRange(pack,8,16);
            String destStr = longToIP(byteToLong(dest));
            String srcStr = longToIP(byteToLong(src));
            String[] ret = {destStr,srcStr};
            return ret;
        }
        catch (Exception e)
        {
            e.printStackTrace();
            return null;
        }
    }

    public void send(int type, int num, byte[] content, boolean priored)
    {
        try
        {
            ByteArrayOutputStream bytes = new ByteArrayOutputStream();
            byte[] data = PackUpPhy(content);
            bytes.write(data, 0, data.length);
            System.out.println("Sending Package #" + num + " with content:" + new String(content));
            System.out.println();
            phyLayer.send(type, num, bytes.toByteArray(), priored);
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
    }

    public void printHost()
    {
        System.out.println("Package to IP: " + longToIP(this.Dest));
        System.out.println("Package from IP: " + longToIP(this.Src));
    }


}
