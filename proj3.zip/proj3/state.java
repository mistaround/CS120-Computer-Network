public class state
{
    public static final int RECV = 0;
    public static final int RX = 1;
    public static final int TX = 2;
}